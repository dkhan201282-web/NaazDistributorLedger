package com.naaz.distributorledger

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("naaz_ledger", MODE_PRIVATE) }
    private val retailers = mutableListOf<String>()
    private val entries = mutableListOf<Entry>()
    private var selectedRetailer = ""
    private val companies = arrayOf("PayBingo", "Zxpay", "Click Rise")
    private val fmt = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault())
    private data class Entry(val retailer:String,val date:Long,val company:String,val type:String,val amount:Double,val mode:String="",val utr:String="",val cashBreakdown:String="")

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main); load(); wire(); refresh() }
    private fun wire(){
        findViewById<Button>(R.id.addRetailer).setOnClickListener{addRetailer()}
        findViewById<Button>(R.id.giveBalance).setOnClickListener{ifSelected{giveBalance()}}
        findViewById<Button>(R.id.receivePayment).setOnClickListener{ifSelected{receivePayment()}}
        findViewById<Button>(R.id.ledger).setOnClickListener{ifSelected{showLedger()}}
        findViewById<Button>(R.id.dailyReport).setOnClickListener{ifSelected{shareReport()}}
        findViewById<Button>(R.id.selectRetailer).setOnClickListener{selectRetailer()}
    }
    private fun ifSelected(action:()->Unit){ if(selectedRetailer.isBlank()) Toast.makeText(this,"Add/select a retailer first",Toast.LENGTH_SHORT).show() else action() }
    private fun money(v:Double)="₹"+String.format(Locale.getDefault(),"%,.2f",v)
    private fun addRetailer(){
        val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(40,0,40,0)
        val name=EditText(this); name.hint="Retailer / Shop name"; val mobile=EditText(this); mobile.hint="Mobile number (optional)"; mobile.inputType=InputType.TYPE_CLASS_PHONE
        box.addView(name); box.addView(mobile)
        AlertDialog.Builder(this).setTitle("Add Retailer").setView(box).setPositiveButton("Save"){_,_->val n=name.text.toString().trim(); if(n.isNotEmpty()){retailers.add(n); selectedRetailer=n; save(); refresh()}}.setNegativeButton("Cancel",null).show()
    }
    private fun selectRetailer(){ if(retailers.isEmpty()){addRetailer();return}; AlertDialog.Builder(this).setTitle("Select Retailer").setItems(retailers.toTypedArray()){_,which->selectedRetailer=retailers[which];refresh()}.show() }
    private fun giveBalance(){
        val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(40,0,40,0)
        val company=Spinner(this); company.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,companies); val amount=EditText(this); amount.hint="Amount"; amount.inputType=2
        box.addView(company); box.addView(amount)
        AlertDialog.Builder(this).setTitle("Give Balance — $selectedRetailer").setView(box).setPositiveButton("Save"){_,_->val a=amount.text.toString().toDoubleOrNull()?:0.0;if(a>0){entries.add(Entry(selectedRetailer,System.currentTimeMillis(),company.selectedItem.toString(),"GIVEN",a));save();refresh()}}.setNegativeButton("Cancel",null).show()
    }
    private fun receivePayment(){
        val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(40,0,40,0)
        val mode=Spinner(this); mode.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Cash","Online / UPI","Both"));
        fun field(h:String)=EditText(this).apply{hint=h;inputType=2}
        val n50=field("₹50 notes"), n100=field("₹100 notes"), n200=field("₹200 notes"), n500=field("₹500 notes"), online=field("Online amount"), utr=EditText(this).apply{hint="UTR / reference (optional)"}
        listOf(mode,n50,n100,n200,n500,online,utr).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("Receive Payment — $selectedRetailer").setView(box).setPositiveButton("Save"){_,_->
            val c50=(n50.text.toString().toDoubleOrNull()?:0.0).toInt(); val c100=(n100.text.toString().toDoubleOrNull()?:0.0).toInt(); val c200=(n200.text.toString().toDoubleOrNull()?:0.0).toInt(); val c500=(n500.text.toString().toDoubleOrNull()?:0.0).toInt(); val cash=c50*50+c100*100+c200*200+c500*500; val on=online.text.toString().toDoubleOrNull()?:0.0; val total=cash+on
            if(total>0){val breakdown="50×$c50, 100×$c100, 200×$c200, 500×$c500"; entries.add(Entry(selectedRetailer,System.currentTimeMillis(),"","RECEIVED",total,mode.selectedItem.toString(),utr.text.toString(),breakdown));save();refresh()}
        }.setNegativeButton("Cancel",null).show()
    }
    private fun totals(r:String):Triple<Double,Double,Double>{var g=0.0;var p=0.0;entries.filter{it.retailer==r}.forEach{if(it.type=="GIVEN")g+=it.amount else p+=it.amount};return Triple(g,p,g-p)}
    private fun refresh(){
        val (g,p,o)=if(selectedRetailer.isBlank()) Triple(0.0,0.0,0.0) else totals(selectedRetailer)
        findViewById<TextView>(R.id.summary).text="Retailer: ${if(selectedRetailer.isBlank())"None" else selectedRetailer}\n\nBalance Given: ${money(g)}\nReceived: ${money(p)}\nOutstanding: ${money(o)}\n\nRetailers: ${retailers.size}"
        findViewById<TextView>(R.id.log).text=entries.filter{it.retailer==selectedRetailer}.takeLast(8).reversed().joinToString("\n\n"){e->"${fmt.format(Date(e.date))} | ${if(e.type=="GIVEN")e.company+" BALANCE GIVEN" else e.mode+" RECEIVED"} | ${money(e.amount)}${if(e.utr.isNotBlank())" | UTR ${e.utr}" else ""}"}
    }
    private fun showLedger(){val list=entries.filter{it.retailer==selectedRetailer};val (_,_,o)=totals(selectedRetailer);AlertDialog.Builder(this).setTitle("Ledger — $selectedRetailer").setMessage((if(list.isEmpty())"No transactions." else list.joinToString("\n\n"){e->"${fmt.format(Date(e.date))}\n${if(e.type=="GIVEN")"${e.company} • BALANCE GIVEN" else "${e.mode} • PAYMENT RECEIVED"}\n${money(e.amount)}${if(e.cashBreakdown.isNotBlank())"\nCash: ${e.cashBreakdown}" else ""}${if(e.utr.isNotBlank())"\nUTR: ${e.utr}" else ""}"})+"\n\nOutstanding: ${money(o)}").setPositiveButton("OK",null).show()}
    private fun shareReport(){val list=entries.filter{it.retailer==selectedRetailer};val(g,p,o)=totals(selectedRetailer);val text="*${selectedRetailer} — Daily Statement*\nDate: ${SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(Date())}\n\nBalance Given: ${money(g)}\nPayments Received: ${money(p)}\n*Outstanding: ${money(o)}*\n\nRecent Transactions:\n"+list.takeLast(20).joinToString("\n"){e->"${fmt.format(Date(e.date))} | ${if(e.type=="GIVEN")e.company+" GIVEN" else e.mode+" RECEIVED"} | ${money(e.amount)}"};startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,text)},"Share statement"))}
    private fun save(){val ro=JSONArray();retailers.forEach{ro.put(it)};val eo=JSONArray();entries.forEach{e->eo.put(JSONObject().apply{put("r",e.retailer);put("d",e.date);put("c",e.company);put("t",e.type);put("a",e.amount);put("m",e.mode);put("u",e.utr);put("b",e.cashBreakdown)})};prefs.edit().putString("retailers",ro.toString()).putString("entries",eo.toString()).putString("selected",selectedRetailer).apply()}
    private fun load(){
        try {
            val ro=JSONArray(prefs.getString("retailers","[]")); for(i in 0 until ro.length()) retailers.add(ro.getString(i))
            val eo=JSONArray(prefs.getString("entries","[]")); for(i in 0 until eo.length()){ val x=eo.getJSONObject(i); entries.add(Entry(x.getString("r"),x.getLong("d"),x.getString("c"),x.getString("t"),x.getDouble("a"),x.optString("m"),x.optString("u"),x.optString("b"))) }
            selectedRetailer=prefs.getString("selected","") ?: ""
            if(selectedRetailer.isBlank()) selectedRetailer=retailers.firstOrNull() ?: ""
        } catch(_:Exception) { selectedRetailer=retailers.firstOrNull() ?: "" }
    }
}
