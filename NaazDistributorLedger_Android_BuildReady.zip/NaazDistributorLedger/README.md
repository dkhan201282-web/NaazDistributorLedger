# Naaz Distributor Ledger

Android app for distributor-retailer account management.

Features in this build:
- Multiple retailers stored locally
- PayBingo, Zxpay and Click Rise balance entries
- Cash collections with ₹50/₹100/₹200/₹500 denomination counts
- Online/UPI collections and UTR/reference
- Automatic retailer outstanding balance
- Ledger view and WhatsApp share
- GitHub Actions workflow to build an installable debug APK

## Phone-only APK build
1. Create a GitHub repository named `NaazDistributorLedger`.
2. Upload all files in this folder to the `main` branch.
3. Open **Actions** → **Build APK** → **Run workflow**.
4. Open the completed workflow run and download `NaazDistributorLedger-debug-apk`.
5. Extract the ZIP and install `app-debug.apk` on Android.

The debug APK is unsigned for Play Store distribution but can be installed directly after allowing installation from the browser/file manager when Android asks.
